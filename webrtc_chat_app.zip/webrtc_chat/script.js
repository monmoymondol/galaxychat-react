// Firebase config
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const database = firebase.database();

const yourId = Math.floor(Math.random() * 1000000000);
document.getElementById("yourId").value = yourId;

const peerConnection = new RTCPeerConnection({
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
});
peerConnection.onicecandidate = event => {
    if (event.candidate) {
        sendMessageToFirebase(yourId, JSON.stringify({ candidate: event.candidate }));
    }
};

let dataChannel = peerConnection.createDataChannel("chat");
dataChannel.onmessage = e => {
    document.getElementById("messages").value += "Peer: " + e.data + "\n";
};

peerConnection.ondatachannel = event => {
    dataChannel = event.channel;
    dataChannel.onmessage = e => {
        document.getElementById("messages").value += "Peer: " + e.data + "\n";
    };
};

function sendMessageToFirebase(sender, data) {
    const msg = database.ref("messages").push();
    msg.set({ sender, message: data });
}

function readMessagesFromFirebase() {
    database.ref("messages").on("child_added", data => {
        const msg = data.val();
        if (msg.sender != yourId) {
            const content = JSON.parse(msg.message);
            if (content.sdp) {
                peerConnection.setRemoteDescription(new RTCSessionDescription(content.sdp)).then(() => {
                    if (content.sdp.type === "offer") {
                        peerConnection.createAnswer().then(answer => {
                            peerConnection.setLocalDescription(answer);
                            sendMessageToFirebase(yourId, JSON.stringify({ sdp: answer }));
                        });
                    }
                });
            } else if (content.candidate) {
                peerConnection.addIceCandidate(new RTCIceCandidate(content.candidate));
            }
        }
    });
}

readMessagesFromFirebase();

function sendMessage() {
    const input = document.getElementById("messageInput");
    const message = input.value;
    dataChannel.send(message);
    document.getElementById("messages").value += "You: " + message + "\n";
    input.value = "";
}

function connect() {
    const peerId = document.getElementById("peerId").value;
    peerConnection.createOffer().then(offer => {
        peerConnection.setLocalDescription(offer);
        sendMessageToFirebase(yourId, JSON.stringify({ sdp: offer }));
    });
}
