import React from 'react';
import './LandingPage.css';

const LandingPage = () => {
  return (
    <div className="landing">
      <h1>GalaxyCHAT</h1>
      <p>A smarter way to think — powered by GPT-3.5 & GPT-4</p>
      <button onClick={() => alert("Start Chatting")}>Start Chatting</button>
    </div>
  );
};

export default LandingPage;
