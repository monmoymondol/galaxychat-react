import React, { useState } from 'react';
import MessageInput from './MessageInput';

const ChatDashboard = () => {
  const [messages, setMessages] = useState([]);
  const [model, setModel] = useState('gpt-3.5');

  const sendMessage = (text) => {
    const newMessage = { role: 'user', text };
    setMessages([...messages, newMessage]);
    // You'd connect to the OpenAI API here
  };

  return (
    <div className="chat-dashboard">
      <div className="header">
        <h2>GalaxyCHAT</h2>
        <select value={model} onChange={(e) => setModel(e.target.value)}>
          <option value="gpt-3.5">Fast & Light (GPT-3.5)</option>
          <option value="gpt-4">Smart & Deep (GPT-4)</option>
        </select>
      </div>
      <div className="chat-window">
        {messages.map((msg, idx) => (
          <div key={idx} className={`message ${msg.role}`}>{msg.text}</div>
        ))}
      </div>
      <MessageInput onSend={sendMessage} />
    </div>
  );
};

export default ChatDashboard;
