import React from 'react';
import LandingPage from './components/LandingPage';
import ChatDashboard from './components/ChatDashboard';

function App() {
  return (
    <div className="App">
      {/* You can toggle between landing and dashboard here */}
      <LandingPage />
      {/* <ChatDashboard /> */}
    </div>
  );
}

export default App;
