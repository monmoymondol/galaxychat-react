const chatBox = document.getElementById("chat-box");
const chatInput = document.getElementById("chat-input");

function sendMessage() {
    const text = chatInput.value.trim();
    if (text === "") return;

    const message = document.createElement("div");
    message.textContent = "You: " + text;
    message.className = "chat-message";
    chatBox.appendChild(message);
    chatInput.value = "";
    chatBox.scrollTop = chatBox.scrollHeight;
}
